const Stripe = require('stripe');
const stripe = Stripe('stripe-key-xxxxx'); //stripe secret test key

//Lambda function

//Will include - firebase uid / user email / stripe token id
exports.handler = async function(event, context, callback){

  var token = '';
  var emailAddress = '';
  var uid = '';
  //check query params
  if(event.hasOwnProperty('queryStringParameters')){
    var params = event.queryStringParameters;
    if(params.hasOwnProperty('token')){
      token = event.queryStringParameters.token;
    }
    if(params.hasOwnProperty('uid')){
      uid = event.queryStringParameters.uid;
    }
    if(params.hasOwnProperty('email')){
      emailAddress = event.queryStringParameters.email;
    }
  }

  if(uid != ''){

    //First Create customer

    //add stripe error handling ... https://stripe.com/docs/api/errors/handling
    //https://github.com/stripe/stripe-node/wiki/Error-Handling
    const customer = await stripe.customers.create({
      email: emailAddress,
      description: uid,
      source: token
    });
    var customerStripeId = customer.id;


    //***Process Charge***
    //Explain for the latest Stripe Methods to check their API Docs
    //Process for customer with priceid
    const subscription = await stripe.subscriptions.create({
      customer: customerStripeId,
      items: [
        {price: 'price_xxxxxx'}, //change here for one-time-fee or subscription...
      ],
    });


    return customerStripeId;

  }else{
    callback(null, {
      "status": "error",
      "message": "missing params",
    });
  }

};
